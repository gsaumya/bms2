package com.cts.bankmanagement.vo;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Range;

public class TransactionVo {

	@Range(min = 1000000000000000L, max = 9999999999999999L, message = "Account number should have 16 digits")
	private Long accountNumber;

	private Long transactionId;

	/*@NotNull(message = "Account holder name can't be empty")
	@Size(min = 8, max = 16, message = "Account holder name should have between 8 and 16 characters")*/
	private String customerName;

	/*@Pattern(regexp = "SAVING|CURRENT|DMAT", message = "Empty or invalid account type")*/
	private String transactionType;
	private Double transactionAmount;
	private String description;

	public TransactionVo() {
		// TODO Auto-generated constructor stub
	}

	public TransactionVo(Long accountNumber,  String customerName, String transactionType,
			Double transactionAmount, String description) {
		super();
		this.accountNumber = accountNumber;
	
		this.customerName = customerName;
		this.transactionType = transactionType;
		this.transactionAmount = transactionAmount;
		this.description = description;
	}

	public Long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public Long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public Double getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(Double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}

package com.cts.bankmanagement.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.cts.bankmanagement.entity.TransactionDetail;
import com.cts.bankmanagement.vo.TransactionVo;

@Repository("viewDao")
public class ViewTransactionDaoImpl implements ViewTransactionDao {

	@Autowired
	private SessionFactory sessionFactory;

	private List<TransactionVo> getTransactionsVo(List<TransactionDetail> transactions) {
		if (CollectionUtils.isEmpty(transactions)) {
			return Collections.emptyList();
		}

		List<TransactionVo> usersVO = new ArrayList<TransactionVo>(transactions.size());
		for (TransactionDetail user : transactions) {
			usersVO.add(getTransactionVo(user));
		}
		return usersVO;
	}

	private TransactionVo getTransactionVo(TransactionDetail transactionDetails) {
		return new TransactionVo(transactionDetails.getAccountNumber(),
				transactionDetails.getCustomerName(), transactionDetails.getTransactionType(),
				transactionDetails.getTransactionAmount(), transactionDetails.getDescription());

	}

	@SuppressWarnings("unchecked")
	@Override
	public TransactionVo getTransactionDao(Long transactionId) {
		Query query = sessionFactory.getCurrentSession()
				.createQuery("from TransactionDetail where " + "transactionId = :transactionId");
		query.setParameter("transactionId", transactionId);
		List<TransactionDetail> list = query.list();
		if(CollectionUtils.isEmpty(list)) {
			return null;
		}
		return getTransactionVo(list.get(0));
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TransactionVo> getTransactionDetails(Long accountNumber) {
		Query query = sessionFactory.getCurrentSession()
				.createQuery("from TransactionDetail where " + "accountNumber = :accountNumber");
		query.setParameter("accountNumber", accountNumber);
		return query.list();
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<TransactionVo> getTransactionDetails(Long accountNumber, Long transactionId) {
		Query query = sessionFactory.getCurrentSession().createQuery(
				"from TransactionDetail where accountNumber " + "= :acNo and transactionId = :transactionId");
		query.setParameter("acNo", accountNumber);
		query.setParameter("transactionId", transactionId);
		return getTransactionsVo((List<TransactionDetail>) query.list());
	}
}

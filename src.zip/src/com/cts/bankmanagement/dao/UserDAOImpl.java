package com.cts.bankmanagement.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.cts.bankmanagement.entity.UserDetails;

import com.cts.bankmanagement.vo.UserVO;

@Repository("userDao")
public class UserDAOImpl implements UserDAO {

	@Autowired
	private SessionFactory sessionFactory;

    @Override
    public void updateUserDetails(UserVO userVO) {
           sessionFactory.getCurrentSession()
                        .createQuery("update UserDetails set accountBalance = :balance where accountNumber = :accountNumber")
                        .setParameter("balance", userVO.getAccountBalance())
                        .setParameter("accountNumber", userVO.getAccountNumber()).executeUpdate();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<UserVO> getUsersDetails() {
           List<UserDetails> users = sessionFactory.getCurrentSession().createCriteria(UserDetails.class).list();
           return getUsersVO(users);
    }

    @Override
    public UserVO getUserDetails(Long accountNumber) {
           return getUserVO((UserDetails) sessionFactory.getCurrentSession().get(UserDetails.class, accountNumber));
    }

    private UserVO getUserVO(UserDetails user) {
           if (user != null) {
                  return new UserVO(user.getAccountNumber(), user.getAccountType(), user.getAccountHolderName(),
                               user.getAccountBalance());
           }
           return null;
    }

    private List<UserVO> getUsersVO(List<UserDetails> users) {
           if (CollectionUtils.isEmpty(users)) {
                  return Collections.emptyList();
           }

           List<UserVO> usersVO = new ArrayList<UserVO>(users.size());
           for (UserDetails user : users) {
                  usersVO.add(getUserVO(user));
           }
           return usersVO;
    }

	

	
}






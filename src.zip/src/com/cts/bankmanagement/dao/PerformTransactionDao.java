package com.cts.bankmanagement.dao;

import com.cts.bankmanagement.vo.TransactionVo;

public interface PerformTransactionDao {
	Double updateTransactionDetail(TransactionVo transactionVo);
	
	
}

package com.cts.bankmanagement.dao;

import java.util.List;

import com.cts.bankmanagement.vo.TransactionVo;

public interface ViewTransactionDao {

	TransactionVo getTransactionDao(Long transactionId);

	List<TransactionVo> getTransactionDetails(Long accountNumber, Long transactionId);

	List<TransactionVo> getTransactionDetails(Long accountNumber);
}

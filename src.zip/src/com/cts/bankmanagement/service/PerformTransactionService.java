package com.cts.bankmanagement.service;

import com.cts.bankmanagement.exception.BankManagementException;
import com.cts.bankmanagement.vo.TransactionVo;

public interface PerformTransactionService {
	
	
	public Double updateTransactionDetail(TransactionVo transactionVo) throws BankManagementException;
	
	

}

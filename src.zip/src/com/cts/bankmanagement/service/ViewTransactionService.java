package com.cts.bankmanagement.service;

import java.util.List;

import com.cts.bankmanagement.vo.TransactionVo;

public interface ViewTransactionService {

	List<TransactionVo> retreiveTransactionService(Long accountNumber, Long transactionId);

	//List<TransactionVo> getTransactionsVo(Long accountNumber, Long transactionId);

	
}

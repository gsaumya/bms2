package com.cts.bankmanagement.service;

import java.text.MessageFormat;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.bankmanagement.dao.PerformTransactionDao;
import com.cts.bankmanagement.dao.UserDAO;
import com.cts.bankmanagement.exception.BankManagementException;
import com.cts.bankmanagement.vo.TransactionVo;
import com.cts.bankmanagement.vo.UserVO;

@Service("transactionService")
public class PerformTransactionServiceImpl implements PerformTransactionService {

	@Autowired
	private UserDAO userDao;

	private final static String DEPOSIT = "deposit";
	private final static String WITHDRAWAL = "withdrawal";

	@Autowired
	PerformTransactionDao transactionDao;

	@Transactional
	@Override
	public Double updateTransactionDetail(TransactionVo transactionVo) throws BankManagementException {

		UserVO userVO = userDao.getUserDetails(transactionVo.getAccountNumber());
		if (userVO == null) {
			throw new BankManagementException(
					MessageFormat.format("Invalid Account No: {0}", transactionVo.getAccountNumber()));
		}

		Double accountBalance = userVO.getAccountBalance() == null ? 0 : userVO.getAccountBalance();
		Double transaction_amount = transactionVo.getTransactionAmount();
		if (DEPOSIT.equalsIgnoreCase(transactionVo.getTransactionType())) {
			accountBalance += transaction_amount;
			userVO.setAccountBalance(accountBalance);
			userDao.updateUserDetails(userVO);
		}

		if (WITHDRAWAL.equalsIgnoreCase(transactionVo.getTransactionType())) {
			accountBalance -= transaction_amount;
			userVO.setAccountBalance(accountBalance);
			userDao.updateUserDetails(userVO);
		}

		 transactionDao.updateTransactionDetail(transactionVo);
		 return accountBalance;

	}

}

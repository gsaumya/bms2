package com.cts.bankmanagement.service;

public class ApplicationService  {
	// Add appropriate annotations and code wherever required
}

package com.cts.bankmanagement.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.cts.bankmanagement.exception.BankManagementException;
import com.cts.bankmanagement.service.PerformTransactionService;
import com.cts.bankmanagement.vo.TransactionVo;

@Controller
public class PerformTransactionController {

	@Autowired
	private PerformTransactionService transactionService;
	@Autowired
	private Validator validator;

	@ResponseBody
	@RequestMapping(value = "performtransaction", method = RequestMethod.POST)
	ModelAndView initiateTransaction(@RequestParam(value = "accountNumber") Long accountNumber,
		
			@RequestParam(value = "customerName") String customerName,
			@RequestParam(value = "transactionType") String transactionType,
			@RequestParam(value = "transactionAmount") Double transactionAmount,
			@RequestParam(value = "description") String description) throws BankManagementException {

		TransactionVo transactionvo = new TransactionVo(accountNumber, customerName, transactionType,
				transactionAmount, description);

		Set<ConstraintViolation<TransactionVo>> validationErrors = validator.validate(transactionvo);
		if (!validationErrors.isEmpty()) {
			// got errors, return error messages
			Map<String, String> errors = getVallidationErrors(validationErrors);
			return new ModelAndView("Transaction/performTransaction", "errors", errors);
		}
		Double tid = transactionService.updateTransactionDetail(transactionvo);
		transactionvo.setTransactionAmount(tid);
		return new ModelAndView("transaction", "user", tid);

	}

	private Map<String, String> getVallidationErrors(Set<ConstraintViolation<TransactionVo>> validationErrors) {
		Map<String, String> errors = new HashMap<String, String>(validationErrors.size());
		for (ConstraintViolation<TransactionVo> constraintViolation : validationErrors) {
			errors.put(constraintViolation.getPropertyPath().toString(), constraintViolation.getMessage());
		}
		return errors;

	}

	@RequestMapping(value = "/performtransactionForm")
	public String performTransactionForm() {
		return "Transaction/performTransaction";
	}
}
